package com.huawei.instance;
/*
true �C if variable is instance of specified class, it��s parent class or implement specified interface or it��s parent interface
false �C if variable is not instance of the class or implement the interface; or variable is null*/

class ArrayInstance {
	
	public static void main(String[] args) {
		int[] intArr= {323,434,543,56,676};
		float[] floatArr= {2324324.45f,4356f,4534.46f};
		Integer[] integerArr= {242345,564654,6757,64534};
		String[] stringArr= {"bad","asdf","affv"};
		
		String str="";
		
		
		System.out.println(intArr instanceof int[]);
		System.out.println(intArr instanceof Object);
		
		
		System.out.println(floatArr instanceof float[]);
		System.out.println(floatArr instanceof Object);
		
		
		System.out.println(stringArr instanceof String[]); 
		
		System.out.println(integerArr instanceof Object);
		System.out.println(integerArr instanceof Object[]);
		System.out.println(integerArr instanceof Integer[]);
		System.out.println(integerArr instanceof Number[]);
		
		if(str instanceof String ) {
			System.out.println("Null"); 
		}else {
			System.out.println("Not null");
		}
		
	}

}
