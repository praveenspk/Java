package com.huawei.instance;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class AvoidindClassCastException {
	public static void main(String[] args) {

		List<String> list = new ArrayList<>();
		list.add("P");
		list.add("Pk");
		list.add("SPk");
		list.add("Pk");
		list.add("K");
		// LinkedList<String> linkedList=(LinkedList<String>) list;//java.util.ArrayList
		// cannot be cast to java.util.LinkedList
		
		System.out.println(list);
		if(list instanceof LinkedList)
		{
		    LinkedList<String> linkedList = (LinkedList<String>) list;
		     linkedList.add("");
		     linkedList.addAll(list);
		     System.out.println(linkedList);
		}
	}

}
