package com.huawei.instance;

import java.util.ArrayList;
import java.util.Iterator;

public class ListDatatype {
	public static void main(String[] args) {
		ArrayList<Object> myList = new ArrayList<>();
		myList.add("Praveen");
		myList.add(9490137902L);
		//myList.add(true);
		myList.add(25000.56);
		myList.add('S');

		Iterator<Object> itr = myList.iterator();
	
		while (itr.hasNext()) {
			Object obj = itr.next();

			if (obj instanceof String) {
				System.out.println(obj + " : is String");
			} else if (obj instanceof Integer) {
				System.out.println(obj + " :  is Integer");
			} else if (obj instanceof Double) {
				System.out.println(obj + " : is Double");
			} else if (obj instanceof Long) {
				System.out.println(obj + " : is Long");
			} else if (obj instanceof Character) {
				System.out.println(obj + " : is Character");
			}
			

		}
	}

}
