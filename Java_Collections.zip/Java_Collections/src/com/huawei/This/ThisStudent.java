package com.huawei.This;

 class Student {

	int age;
	String name;

	// Parameterized Constructor
	Student(int age,String name)
	{
	
		this.age=age;
		this.name=name;
		this.disp();//Calling method with this
	}

	public void disp() {
		System.out.println("Name : " + name + " Age : " + age);
	}

}

public class ThisStudent {
	public static void main(String args[]) {
		Student s = new Student(10, "JavaInterviewPoint");
		//s.disp();
	}
}
