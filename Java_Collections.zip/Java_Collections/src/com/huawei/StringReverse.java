package com.huawei;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import com.lowagie.text.pdf.codec.Base64.InputStream;

public class StringReverse {
	static void removeDuplicates(String str) {

		String string = "";
		for (int i = 0; i < str.length(); i++) {
			for (int j = i + 1; j < str.length(); j++) {
				if (str.charAt(i) == str.charAt(j)) {

					string = str.charAt(j) + " " + str.charAt(i);
				}
			}
		}
		System.out.println(string);
	}

	static void reverseString(String str) {
		char[] ch = str.toCharArray();
		String string = "";
		for (int i = ch.length - 1; i >= 0; i--) {
			System.out.println(ch[i]);
			string = string + ch[i] + "";
		}
		System.out.println(string);
	}

	public static void main(String[] args) {
		// reverseString("praveen");
		removeDuplicates("Praveen");
	
	}

}
