package com.huawei;

public class SysExit {
	public static void main(String[] args) {

		try {
			System.out.println("Started.....");
			System.exit(0);
			System.out.println("Ended");
		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			System.out.println("Finally block");
			System.exit(0); // Daemon Thread
			System.out.println("Started.....");
		}

	}

}
