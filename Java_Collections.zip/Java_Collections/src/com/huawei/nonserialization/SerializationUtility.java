package com.huawei.nonserialization;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
/*
We will be using java.util.ObjectOutputStream and 
java.util.ObjectInputStream to write/read object to/from the file ��Persist.txt��*/

public class SerializationUtility {

	/*
	 * serialize() : we will make use of java.util.ObjectOutput stream to write the
	 * Object which we pass, to the file ��Persist.txt��
	 */
	public void serialize(Object obj, String filePath) throws IOException {

		FileOutputStream fileOp = new FileOutputStream(filePath);
		ObjectOutputStream objOp = new ObjectOutputStream(fileOp);
		objOp.writeObject(obj);
		objOp.flush();
		objOp.close();
	}
	/*
	 * deSerialize(): java.util.ObjectInputStream is used to read the Object from
	 * the file and return it back to the user.
	 */

	public Object deserialize(String filePath) {

		Object obj = null;

		try {
			FileInputStream input = new FileInputStream(filePath);
			ObjectInputStream objInput = new ObjectInputStream(input);
			obj = objInput.readObject();

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return obj;
	}
}
