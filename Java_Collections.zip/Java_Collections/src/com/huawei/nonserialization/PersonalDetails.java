package com.huawei.nonserialization;

/**
 * @author s84119411
 *
 */
public class PersonalDetails {

	private String email;
	private Long mobile;

	public PersonalDetails() {
		System.out.println("Default Constructor");
	}
	

	public PersonalDetails(String email, Long mobile) {
		super();
		this.email = email;
		this.mobile = mobile;
	}


	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Long getMobile() {
		return mobile;
	}

	public void setMobile(Long mobile) {
		this.mobile = mobile;
	}

	@Override
	public String toString() {
		return "PersonalDetails [email=" + email + ", mobile=" + mobile + "]";
	}

}
