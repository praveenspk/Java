package com.huawei.nonserialization;

import java.io.IOException;

/*
Exception in thread "main" java.io.NotSerializableException: com.huawei.nonserialization.PersonalDetails*/

public class NonSerialization_Exception {
	public static void main(String[] args) throws IOException {

		Employee emp = new Employee(5646, "praveen", "Bangalore", new PersonalDetails("praveen@spk.com", 9490137902L));
		SerializationUtility util = new SerializationUtility();
		util.serialize(emp, "input.txt");
		Employee em = (Employee) util.deserialize("input.txt");
		System.out.println(em.getId());

	}

}
