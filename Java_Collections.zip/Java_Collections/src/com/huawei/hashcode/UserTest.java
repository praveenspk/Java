package com.huawei.hashcode;

public class UserTest {
	public static void main(String[] args) {
		User user1 = new User("Praveen", 25, "84119411");
		User user2 = new User("Praveen", 25, "84119411");
		System.out.println(user1.equals(user2)); // true
		
	}
}
