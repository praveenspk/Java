package com.huawei.comparables;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SortEmp {
	public static void main(String args[]) {
		List l = new ArrayList();
		l.add(new Employee(30, "jip"));
		l.add(new Employee(20, "javainterviewpoint"));
		l.add(new Employee(10, "javainterview"));

		Collections.sort(l);
		System.out.println("Sorted elements are : " + l);
	}

}
