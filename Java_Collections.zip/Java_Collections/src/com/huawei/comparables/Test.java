package com.huawei.comparables;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class Test {
	static <K, V> void sortMap(Map<K, V> map) {
		for (Map.Entry<K, V> entry : map.entrySet()) {
			System.out.println("Key : " + entry.getKey() + " Value : " + entry.getValue());
		}

	}

	public static void main(String[] args) {
		Map<Integer, Employee> map = new HashMap<>();

		map.put(84119411, new Employee(9728, "Praveen"));
		map.put(84119412, new Employee(68723, "Mohan"));
		map.put(85261322, new Employee(565412, "Sravan"));
		map.put(84119419, new Employee(9728, "Vardhan"));
		map.put(84119422, new Employee(68723, "Suresh"));
		map.put(85261343, new Employee(565412, "Thimothy"));
		
		Map<Integer,Employee> treeMap=new TreeMap<>(map);
		System.out.println(treeMap);
		sortMap(treeMap);
		

	}

}
