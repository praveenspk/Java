package com.huawei.comparables;

class Employee implements Comparable<Employee> {
	private String empname;
	private int eid;

	public Employee(int eid, String empname) {
		this.eid = eid;
		this.empname = empname;
	}

	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}

	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public String toString() {
		return " \n id : " + this.eid + " empname : " + this.empname;
	}

	public int compareTo(Employee e) {
		// TODO Auto-generated method stub
		return (this.getEid() - e.getEid());
	}

	
}