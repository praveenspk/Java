package com.huawei.csv;

import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.StringTokenizer;

public class CSVCreator {

	public static void createCSV() {
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("Name").append(",").append("Website").append(",").append("Location").append("\n");
		stringBuilder.append("Praveen").append(",").append("www.praveen.com").append(",").append("Bangalore")
				.append("\n");
		stringBuilder.append("Vardhan").append(",").append("www.vardhan.com").append(",").append("Chennai")
				.append("\n");
		stringBuilder.append("Suresh").append(",").append("www.vsuresh.com").append(",").append("Hyderabad")
				.append("\n");
		stringBuilder.append("Thimothy").append(",").append("www.thimothy.com").append(",").append("Bangalore")
				.append("\n");
		try (FileWriter writer = new FileWriter("src/com/huawei/csv/website.csv")) {
			writer.write(stringBuilder.toString());

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	static void readCSV() {
		try (BufferedReader br = Files.newBufferedReader(Paths.get("src/com/huawei/csv/website.csv"))){
			String str=" ";
			StringBuilder builder=new StringBuilder();
			while((str=br.readLine())!=null) {
				StringTokenizer token=new StringTokenizer(str,"");
				while(token.hasMoreElements()) {
					System.out.println(token.nextElement());
					
				}
			}
			System.out.println(builder.toString());
		}catch(Exception e) {
			e.printStackTrace();
		}

	}

	public static void main(String[] args) {
		createCSV();
		readCSV();

	}
}
