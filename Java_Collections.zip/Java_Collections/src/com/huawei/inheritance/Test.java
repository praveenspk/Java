package com.huawei.inheritance;

public class Test implements Interface_One, InterfaceTwo {

	public static void main(String[] args) {
		new Test().anyMethod();
	}
}

