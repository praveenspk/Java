/**
 * 
 */
/**
 * @author s84119411
 *
 */
package com.huawei.inheritance;