package com.huawei.thread;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ImageInsert {

	private final String query = "SELECT * FROM test_db.example;";

	static void insertData() throws ClassNotFoundException, FileNotFoundException {

		Connection con = null;
		PreparedStatement stmnt = null;
		InputStream is = null;

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/demo", "root", "root");
			String sql = "insert into example values(?,?,?,?)";
			stmnt = con.prepareStatement(sql);
			String path = "src\\img\\java.jpeg";
			is = new FileInputStream(new File(path));

			stmnt.setInt(1, 1);
			stmnt.setString(2, "sai");
			stmnt.setString(3, "cse");
			stmnt.setBinaryStream(4, is);
			stmnt.executeUpdate();

			if (stmnt != null) {
				System.out.println("Success");
			} else
				System.out.println("Failed...");
		} catch (SQLException se) {
			se.getMessage();
		}

	}

	public static void main(String[] args) throws ClassNotFoundException, FileNotFoundException {
		insertData();
	}

}
