package com.huawei.thread;

class MyThreadJob implements Runnable {

	String msg;

	public MyThreadJob(String msg) {
		super();
		this.msg = msg;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub

		for (int i = 0; i < 10; i++) {
			System.out.println(msg + " " + i);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}

public class ThreadJobs {
	public static void main(String[] args) {

		MyThreadJob job1 = new MyThreadJob("Cutting Ticket");
		MyThreadJob job2 = new MyThreadJob("sitting on theatre ");

		Thread t1 = new Thread(job1);
		Thread t2 = new Thread(job2);

		t1.start();
		t2.start();
	}

}
