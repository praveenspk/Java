package com.huawei.heap;

public class HeapSize {

	static void getHeapSize() {

		int mb = 1024 * 1024;
		// Heap size in Bytes
		long heapTotalSize = (Runtime.getRuntime().totalMemory()) / mb;
		long heapMaxSize = (Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory()) / mb;
		long heapFree = (Runtime.getRuntime().freeMemory()) / mb;
		System.out.println("Total Memory : " + heapTotalSize + " MB\nUsedMemory : " + heapMaxSize
				+ " MB\nFree Memory :  " + heapFree);

		// Heap size in MegaBytes

		Runtime runtime = Runtime.getRuntime();
		long usedMemory = (runtime.totalMemory() - runtime.freeMemory()) / mb;
		System.out.println("Used Memory : " + usedMemory + " MB");

		long usedMaxMemory = (runtime.freeMemory() / mb);
		System.out.println("Free Memory :" + usedMaxMemory + " MB");

		long totalMemory = runtime.totalMemory() / mb;

		System.out.println("Total Memory : " + totalMemory + " MB");
	}

	public static void main(String[] args) {
		getHeapSize();

	}
}
