package com.huawei.set;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public class SetDemo {

	// Method 1: Using Native Way
	static void nativeWaySetToString() {

		Set<String> set = new LinkedHashSet<>(Arrays.asList("Praveen", "Vardhan"));
		String[] str = new String[set.size()];
		System.out.println("Original Set : " + set);
		int i = 0;
		for (String s : set)
			str[i++] = s;

		System.out.println("Set to String : " + Arrays.toString(str));
	}

	// Method 2 : toArray()
	static void toArraySetToString(String[] str) {
		Set<String> set = new HashSet<>(Arrays.asList(str));
		System.out.println("Original Set : " + set);
		String[] array = set.toArray(new String[0]);
		System.out.println("Set to String :" + Arrays.toString(array));

	}

	// Method 3 : Array.copyOf()

	static void copyOfString(String[] str) {
		Set<String> set = new HashSet<>(Arrays.asList(str));
		System.out.println("Original Set : " + set);

		String[] array = Arrays.copyOf(set.toArray(), set.size(), String[].class);
		System.out.println("Set to String : " + Arrays.class + Arrays.toString(array));
	}

	// Method 4 : System.arrayCopy()
	static void arrayCopyString(String[] str) {

		Set<String> set = new HashSet<>(Arrays.asList(str));
		System.out.println("Original Set : " + set);
		String[] array = new String[set.size()];
		System.arraycopy(set.toArray(), 0, array, 0, set.size());
		System.out.println("Set to String : " + System.class + Arrays.toString(array));

	}

	// Method 5 : Java 8
	static void java8(String[] str) {
		Set<String> set = new HashSet<>(Arrays.asList(str));
		System.out.println("Original Set : " + set);

		String[] array = set.stream().toArray(String[]::new);
		System.out.println("Set to String : " + Arrays.toString(array));

	}

	public static void main(String[] args) {
		String[] str = { "Java Programming", "Springframework" };
		nativeWaySetToString();
		toArraySetToString(str);
		copyOfString(str);
		arrayCopyString(str);
		java8(str);

	}

}
