package com.huawei.date;

import java.sql.Timestamp;
import java.util.Date;

public class TimeStampToDate {

	public static void main(String[] args) {
		Timestamp stamp = new Timestamp(System.currentTimeMillis());
		Date date = new Date(stamp.getTime());
		Date dates = stamp;
		System.out.println(date + "\n" + dates);
	}

}
