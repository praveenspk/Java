package com.huawei.exception;

import java.util.Optional;

public class NullPointerExcptionDemo {

	public static void main(String[] args) {

		Employee prince = new Employee();
		// Employee prince = null;
		System.out.println(prince.details());
		
		
		/*
		 * To handle NullPointerException JDK 8 introduces an Optional utility class
		 * inside the java.util package. Optional is a wrapper which may or may not
		 * contains an object, and avoid null uses.
		 */
		

		Optional<Employee> optionalPrince = Optional.ofNullable(prince);
		if (optionalPrince.isPresent()) {
			String princeDetail = optionalPrince.get().details();
			Optional<String> optionalPrinceDetail = Optional.ofNullable(princeDetail);
			if (optionalPrinceDetail.isPresent()) {
				String detail = optionalPrinceDetail.get().toLowerCase();
				System.out.println(detail);
			}
		}
		
		// Java 8 Optional and Functional Interfaces
		
		Optional<String> optionalPrinces = Optional.ofNullable(prince).map(d -> d.details());
		optionalPrinces.ifPresent(s -> System.out.println(s.toLowerCase()));

		
		Optional<String> optionalPrince1 = Optional.ofNullable(prince).map(Employee::details);
		optionalPrince1.ifPresent(System.out::println);
		
	}
}

class Employee {

	public String details() {
		return "Name: Prince, Salary: 55K";
	}
}
