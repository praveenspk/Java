package com.huawei.exception;

/**
 * @author s84119411
 *
 */
public class MyAppException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String message = null;

	public MyAppException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MyAppException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public MyAppException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public MyAppException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public MyAppException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	@Override
	public String toString() {
		return "MyAppException [message=" + message + "]";
	}

}
