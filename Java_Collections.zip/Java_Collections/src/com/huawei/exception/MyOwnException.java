package com.huawei.exception;

public class MyOwnException {

	static void myTest(String str) throws MyAppException {
		if (str == null) {
			throw new MyAppException("String is null");
		}

	}

	public static void main(String[] args) {
		try {
			myTest(null);
		} catch (MyAppException e) {
			// TODO Auto-generated catch block
			System.out.println("Inside catch block : " + e.getMessage());
			e.printStackTrace();
		}
	}

}
