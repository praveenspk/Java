package com.huawei.exception;

public class Test_A {
	public static void display() {

		int[] arr = new int[5];
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}

	}

	public static void main(String[] args) {
		display();

	}

}
