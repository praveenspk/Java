package com.huawei.serialization;

import java.io.IOException;

public class SerializeTest {
	public static void main(String[] args) throws IOException {
		Employee emp = new Employee(8411, "Praveen", "Bangalore");
		String filePath = "input.txt";

		SerializationUtility util = new SerializationUtility();
		// Serialization
		util.serialize(emp, filePath);

		// Deserialization
		System.out.println(util.deserialize(filePath));

		Employee ee = (Employee) util.deserialize(filePath);
		System.out.println(ee.getName() + " " + ee.getId() + " " + ee.getCity());

	}

}
