package com.huawei.dp;

public interface Observer {

	public void update(String stockSymbol, Float stockValue, Integer stockUnit);
}
