package com.huawei.dp;

public class ObserverHandler implements Observer {

	Subject stockData = null;

	public ObserverHandler(Subject stockData) {
		this.stockData = stockData;
		stockData.addObserver(this);
	}

	@Override
	public void update(String stockSymbol, Float stockValue, Integer stockUnit) {
		// TODO Auto-generated method stub

		System.out.println("ObserverHandler Received Changes....!!");
	}

	public static void main(String[] args) {
		System.out.println("Main");
		StockData data=new StockData();
		data.setStockData("Unicorn",87546.324f, 5);
		data.notifyObservers();
		ObserverHandler handler=new ObserverHandler(data);
		handler.update("Buffalo", 62532.908f, 9);

	}
}
