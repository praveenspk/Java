package com.huawei.comparator;

import java.util.ArrayList;
import java.util.Collections;

public class ComparatorTest {
	public static void main(String[] args) {
		ArrayList<Author> list = new ArrayList<Author>();
		list.add(new Author("Prvaeen", "Java Techie", 25));
		list.add(new Author("Vardhan", "Spring Techie", 24));
		list.add(new Author("Thimothy", "Hibernate ", 22));
		list.add(new Author("Amma", ".Net", 40));
		System.out.println(list);
		System.out.println("======Sorting By Author Name ======");
		Collections.sort(list);
		for (Author au : list) {
			System.out.println(au.getFirstName() + " " + au.getBookName() + " " + au.getAuAge());
		}

		Collections.sort(list, new BookNameComparator());
		System.out.println("=======Sorting By Book Name ====");
		for (Author au : list) {
			System.out.println(au.getFirstName() + " " + au.getBookName() + " " + au.getAuAge());
		}

		Collections.sort(list, new AuthorAgeComparator());
		System.out.println("=====Sorting By Age =====");
		for (Author au : list) {
			System.out.println(au.getFirstName() + " " + au.getBookName() + " " + au.getAuAge());
		}

	}

}
