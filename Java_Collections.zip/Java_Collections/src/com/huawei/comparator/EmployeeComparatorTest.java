package com.huawei.comparator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class EmployeeComparatorTest {
	public static void main(String[] args) {
		List<Emp> list = new ArrayList<>();
		list.add(new Emp(857, "Praveen", 7572.748));
		list.add(new Emp(843, "Vardhan", 13572.748));
		list.add(new Emp(823, "Suresh", 65572.748));
		list.add(new Emp(898, "Amma", 2572.748));
		list.add(new Emp(813, "Jysohna", 2572.748));
		list.add(new Emp(643, "Raja", 3572.748));
		list.add(new Emp(943, "Surekha", 8763.748));

		System.out.println("=====Sorting By Name=====");

		Collections.sort(list);
		System.out.println(list);

		Collections.sort(list, new EmpSalaryComparator());
		System.out.println("=====Sorting By Salary=====");
		for (Emp emp : list) {
			System.out.println(emp.getId() + " " + emp.getName() + " " + emp.getSalary());
		}

		System.out.println("=====Sorting By Id=====");
		Collections.sort(list, new EmpIdComparator());
		for (Emp emp : list) {
			System.out.println(emp.getName() + " " + emp.getId() + " " + emp.getSalary());
		}
	}

}
