package com.huawei.comparator;

import java.util.Comparator;

public class BookNameComparator implements Comparator<Author> {

	@Override
	public int compare(Author o1, Author o2) {

		return o1.bookName.compareTo(o2.bookName);
	}

}
