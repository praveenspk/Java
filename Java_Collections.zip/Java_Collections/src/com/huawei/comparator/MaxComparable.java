package com.huawei.comparator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MaxComparable {
	public static void main(String[] args) {
		List<Employee> emps = new ArrayList<Employee>();
		emps.add(new Employee(10, "Raghu", 25000));
		emps.add(new Employee(120, "Krish", 450000));
		emps.add(new Employee(210, "John", 14000));
		emps.add(new Employee(150, "Kishore", 24000));
		Employee maxSal = Collections.max(emps);
		System.out.println("Employee with max salary: " + maxSal);
		System.out.println(emps);

	}

}

class Employee implements Comparable<Employee> {

	private int id;
	private String name;
	private Integer salary;

	public Employee(int id, String name, Integer salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getSalary() {
		return salary;
	}

	public void setSalary(Integer salary) {
		this.salary = salary;
	}

	@Override
	public int compareTo(Employee emp) {
		// TODO Auto-generated method stub
		return this.salary - emp.getSalary();
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + "]";
	}

}
