package com.huawei.comparator;

import java.util.Comparator;

public class AuthorAgeComparator implements Comparator<Author> {

	@Override
	public int compare(Author a1, Author a2) {
		// TODO Auto-generated method stub
		if(a1.auAge==a2.auAge)
			return 0;
		else if(a1.auAge>a2.auAge)
			return 1;
		else
			return -1;
	}

}
