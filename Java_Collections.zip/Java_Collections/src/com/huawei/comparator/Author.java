package com.huawei.comparator;

public class Author implements Comparable<Author> {
	String firstName;
	String bookName;
	int auAge;

	public Author(String firstName, String bookName, int auAge) {
		super();
		this.firstName = firstName;
		this.bookName = bookName;
		this.auAge = auAge;
	}

	public Author() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public int getAuAge() {
		return auAge;
	}

	public void setAuAge(int auAge) {
		this.auAge = auAge;
	}

	@Override
	public int compareTo(Author author) {
		// TODO Auto-generated method stub
		return this.firstName.compareTo(author.firstName);
	}

	@Override
	public String toString() {
		return "Author [firstName=" + firstName + ", bookName=" + bookName + ", auAge=" + auAge + "]";
	}

}
