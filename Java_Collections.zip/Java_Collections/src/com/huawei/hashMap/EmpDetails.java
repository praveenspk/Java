package com.huawei.hashMap;

public class EmpDetails {
	private Long mobile;
	private String Email;
	private String location;

	public EmpDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmpDetails(Long mobile, String email, String location) {
		super();
		this.mobile = mobile;
		Email = email;
		this.location = location;
	}

	public Long getMobile() {
		return mobile;
	}

	public void setMobile(Long mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	@Override
	public String toString() {
		return "EmpDetails [mobile=" + mobile + ", Email=" + Email + ", location=" + location + "]";
	}

}
