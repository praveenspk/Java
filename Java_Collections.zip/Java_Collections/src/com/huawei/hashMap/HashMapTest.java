package com.huawei.hashMap;

import java.util.HashMap;

public class HashMapTest {
	public static void main(String[] args) {
		HashMap<Employee, EmpDetails> map = new HashMap();
		map.put(new Employee(84119411, "praveen"), new EmpDetails(9490137902L, "praveen@spk.com", "Bangalore"));
		map.put(new Employee(84119411, "praveen"), new EmpDetails(9490137902L, "praveen@spk.com", "Bangalore"));
		map.forEach((key, value) -> {
			// System.out.println(key,value);
		});
		System.out.println(map);

	}

}
