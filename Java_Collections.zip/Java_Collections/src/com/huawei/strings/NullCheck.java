//Nullchecking
package com.huawei.strings;

import java.util.ArrayList;
import java.util.List;

public class NullCheck {

	
	public void display(int sum) {

		System.out.println("sum");
	}

	public void display(Object obj) {
		System.out.println("obj");

	}

	public void display(String str) {

		System.out.println("str");
	}

	public static void main(String[] args) {

		NullCheck test = new NullCheck();
		test.display(0);
		
		
	}
}
