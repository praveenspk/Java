package com.huawei.strings;

import java.util.LinkedHashSet;
import java.util.Set;

public class RemoveDuplicates {

	static void removeDuplicates(String str) {

		String string = "";
		for (int i = 0; i < str.length(); i++) {
			for (int j = i + 1; j < str.length(); j++) {
				if (str.charAt(i) == str.charAt(j)) {
					string = string + str.charAt(i) + " ";
				}
			}
		}
		System.out.println(string);

	}

	public static String unique(String s) {
		String str = new String();
		int len = s.length();

		for (int i = 0; i < len; i++) {
			char c=s.charAt(i);
			if(str.indexOf(c)<0) {
				str+=c;
				
			}

		}

		return str;
	}

	static void removeDuplicatesSet() {
		String string = "praveen";

		char[] chars = string.toCharArray();
		Set<Character> charSet = new LinkedHashSet<Character>();
		for (char c : chars) {
			charSet.add(c);
		}
		System.out.println(charSet);

		// Another way
		String s = "praveen";
		Set<Character> set = new LinkedHashSet<Character>();
		for (char c : s.toCharArray()) {
			set.add(Character.valueOf(c));
		}
		System.out.println("Distict String is : " + set);

	}

	public static String removeDuplicate(String input) {
		String result = "";
		for (int i = 0; i < input.length(); i++) {
			if (!result.contains(String.valueOf(input.charAt(i)))) {
				result += String.valueOf(input.charAt(i));
			}
		}
		return result;
	}

	public static void main(String[] args) {

		// removeDuplicates("RaaaaR");
		removeDuplicatesSet();
		System.out.println(removeDuplicate("Praveen"));
		unique("Praveen");

		String stringWithDuplicates = "praveen";
		char[] characters = stringWithDuplicates.toCharArray();
		boolean[] found = new boolean[256];
		StringBuilder sb = new StringBuilder();

		System.out.println("String with duplicates : " + stringWithDuplicates);
		for (char c : characters) {
			if (!found[c]) {
				found[c] = true;
				sb.append(c);
			}
		}
		System.out.println("String after duplicates removed : " + sb.toString());

		String str = "";
		System.out.println(str.indexOf(1));
	}

}
