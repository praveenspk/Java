package com.huawei.strings;

public class LastAndSecondLast {

	static void get(String str) {

		/*
		 * // len_of_a = len(a_string) int len = str.length();
		 * 
		 * String substring = str.length() > 2 ? str.substring(str.length() - 1) : str;
		 * System.out.println(substring); // new_char_1 = a_string[len_of_a-2] // char
		 * ch = str[len - 2]; // char c = str[len - 1];
		 * 
		 * 
		 * // new_char_2 = a_string[len_of_a-1] // String string = c + "" + ch;
		 * 
		 * // new_string = new_char_2+" "+new_char_1
		 * 
		 * // print("Reverse of last 2 letters by adding space in between them:")
		 * 
		 * // System.out.println(string);
		 * 
		 * 
		 * //input string
		 */

		String lastFourDigits = ""; // substring containing last 4 characters

		if (str.length() > 2) {
			lastFourDigits = str.substring(str.length() - 2);
			System.out.println(lastFourDigits);

			char[] ch = lastFourDigits.toCharArray();
			for (int i = ch.length - 1; i >= 0; i--) {
				//System.out.println(ch[i]);
				
				String string=String.valueOf(ch[i]);
				System.out.println(string);
				

			}
			System.out.println(ch);

		} else

		{
			lastFourDigits = str;

		}

		// System.out.println(lastFourDigits);

	}

	static void getLastAndSecondLast(String word) {

		int lastIndex, secondLastIndex;
		lastIndex = word.lastIndexOf(word);
		secondLastIndex = word.lastIndexOf(',', lastIndex - 1);
		System.out.println(word.substring(secondLastIndex + 1, lastIndex));

		/*
		 * char[] ch = word.toCharArray(); String string = ""; for (int i = ch.length -
		 * 1; i >= 0; i--) { System.out.println(ch[i]); //string=String.valueOf(ch[i]);
		 * //System.out.println(string); System.out.println(ch[i]+" "+ch[i-1]); }
		 */

		// System.out.println(word.substring(word.length() - 1) + " " +
		// word.substring(4, word.length() - 2));
	}

	public static void main(String[] args) {
		// getLastAndSecondLast("Praveen");
		get("APPLE");
	}
}
