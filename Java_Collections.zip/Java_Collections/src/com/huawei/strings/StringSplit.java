package com.huawei.strings;

public class StringSplit {
	static void getSpittedString(String str) {
		StringBuffer number = new StringBuffer(), alpha = new StringBuffer(), special = new StringBuffer();
		for (int i = 0; i < str.length(); i++) {
			if (Character.isDigit(str.charAt(i))) {
				number.append(str.charAt(i));
			} else if (Character.isAlphabetic(str.charAt(i))) {
				alpha.append(str.charAt(i));
			} else {
				special.append(str.charAt(i));
			}
		}
		System.out.println(number);
		System.out.println(alpha);
		System.out.println(special);
	}

	public static void main(String[] args) {

		String s1 = "user:8414141";
		String[] words = s1.split("");
		System.out.println(words[0]);

		
		getSpittedString(s1);
	}

}
