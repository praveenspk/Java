package com.huawei.strings;

import java.nio.file.Paths;

public class FirstRecurringChar {
	static char firstRecurringChar(String str) {

		for (int i = 0; i < str.length(); i++) {
			char ch1 = str.charAt(i);
			for (int j = i + 1; j < str.length(); j++) {
				char ch2 = str.charAt(j);
				if (ch1 == ch2) {
					return ch1;
				}
			}
		}

		return 0;

	}

	public static void main(String[] args) {

		String path = Paths.get("").toAbsolutePath().toString();
		System.out.println(System.getProperties());
		System.out.println(System.getProperty("user.dir"));
		System.out.println(System.currentTimeMillis());
		
		System.out.println(path);
		char reOccuringChar = firstRecurringChar("spks");

		System.out.println(reOccuringChar);
		if (reOccuringChar != 0) {
			System.out.println(reOccuringChar + " is the first character to re-occured....!");
		} else {
			System.out.println("No character re-occured....!");
		}
	}

}
