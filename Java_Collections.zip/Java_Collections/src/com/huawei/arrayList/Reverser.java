package com.huawei.arrayList;

import java.util.List;

public interface Reverser {
	List<Integer> reverseList(List<Integer> list);
}