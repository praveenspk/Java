package com.huawei.statics;

public class StaticClass {

	static String str = "Static class";

	public StaticClass() {
		System.out.println("Calling from constructor : " + str);
	}

	public static class StaticDemo {
		static void dislay() {
			System.out.println(str);
		}

	}

	public static void main(String[] args) {
		StaticClass.StaticDemo cls = new StaticClass.StaticDemo();
		StaticClass staticCls=new StaticClass();
		cls.dislay();

	}

}
