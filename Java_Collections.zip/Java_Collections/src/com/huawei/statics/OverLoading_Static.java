package com.huawei.statics;

import java.util.Date;

public class OverLoading_Static {

	static void display() {
		System.out.println("Static overloading...");
	}

	static void display(String name) {
		System.out.println("Static overloading with one param  :" + name);
	}

	static void display(Date date, String city) {
		System.out.println("Static overloading with two param" + date + " - " + city);

	}

	public static void main(String[] args) {
		display();
		display("Praveen");
		display(new Date(),"Bangalore");

	}

}
