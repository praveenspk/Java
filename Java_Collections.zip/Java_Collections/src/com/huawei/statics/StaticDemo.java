package com.huawei.statics;

class StatiTest {
	int i = 20;
	static int j = 20;

	public void increaseData() {
		i++;
		j++;
	}

	public void printData() {
		System.out.println("i= " + i + " J=  " + j);

	}
}

public class StaticDemo {
	public static void main(String[] args) {

		StatiTest test = new StatiTest();
		StatiTest t = new StatiTest();
		test.increaseData();
		t.printData();

	}

}
