package com.huawei.utility;

public class EliminateVowel {
	static String eliminateVowel(String str) {
		return str.replaceAll("[aeiouAEIOU]","");
		
		
	}
	
	public static void main(String[] args) {
		System.out.println(eliminateVowel("Huawei"));
	}

}
