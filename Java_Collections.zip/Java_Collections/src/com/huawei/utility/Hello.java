package com.huawei.utility;

public class Hello {
	static {
		System.out.println("Hello, World!");
	}
}