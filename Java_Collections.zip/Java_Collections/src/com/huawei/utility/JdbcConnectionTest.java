package com.huawei.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcConnectionTest {

	static void insertData() throws ClassNotFoundException {

		Connection con = null;
		Statement stmnt = null;

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/demo", "root", "root");
			if (con != null)
				System.out.println("Connection Successfully");

			stmnt = con.createStatement();
			String sql = "INSERT INTO customer VALUES (35,'Das', 'Dasu', 'dasu@spk.com')";
			stmnt.executeUpdate(sql);

		} catch (SQLException se) {
			se.getMessage();
		}

	}

	static void getDataFromDB() throws SQLException {
		Connection con = null;
		PreparedStatement ps = null;
		Statement st = null;
		boolean result = true;
		ResultSet rs = null;

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/demo", "root", "root");
			st = con.createStatement();
			rs = st.executeQuery("select * from customer");
			System.out.println("ID==FirstName==LastName==Email");
			while (rs.next()) {
				System.out.println(
						rs.getInt(1) + "  " + rs.getString(3) + "  " + rs.getString(4) + " " + rs.getString(2));
			}

		} catch (SQLException se) {
			se.printStackTrace();

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			con.close();
		}

	}

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		insertData();
		getDataFromDB();
	}

}
