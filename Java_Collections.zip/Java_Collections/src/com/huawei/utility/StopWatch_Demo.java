package com.huawei.utility;



import org.apache.commons.lang.time.StopWatch;

public class StopWatch_Demo {

	public static void main(String[] args) {
		StopWatch clock=new StopWatch();
		clock.start();
		//System.Diagnostics.Stopwatch;
		System.out.println();
	}
}
