package com.huawei.utility;

import java.util.Arrays;

public class MinAbsDiff {
	static void getAbsoluteDiff(int[] arr) {
		Arrays.sort(arr);
		int min = Math.abs(arr[0] - arr[1]);
		for (int i = 0; i < arr.length - 1; i++) {
			if (Math.abs(arr[i] - arr[i + 1]) < min) {
				min = Math.abs(arr[i] - arr[i + 1]);
			}
		}
		System.out.println(min);
	}

	static void minSum(int[] arr) {
		int minSum = 0;
		Arrays.sort(arr);
		for (int i = 0; i < arr.length - 1; i++) {
			System.out.println(arr[i]);
			minSum = minSum + arr[i];
		}
		System.out.println(minSum);

	}

	static void maxSum(int[] arr) {
		int maxSum = 0;
		for (int i = 0; i < arr.length; i++) {
			maxSum = maxSum + arr[i];

		}
		System.out.println(maxSum);
	}

	static int minimumAbsoluteDifference(int[] arr) {

		Arrays.sort(arr);
		int min = Math.abs(arr[0] - arr[1]);
		for (int i = 1; i < arr.length - 1; i++) {
			if (Math.abs(arr[i] - arr[i + 1]) < min)
				min = Math.abs(arr[i] - arr[i + 1]);
		}

		return min;
	}

	static int getMinAbsDifference(int[] arr) {
		Arrays.sort(arr);

		int minimumDifference = Integer.MAX_VALUE;
		System.out.println(minimumDifference);

		for (int i = 0; i < arr.length - 1; i++) {
			int difference = arr[i + 1] - arr[i];

			if (difference < minimumDifference) {
				minimumDifference = difference;

				if (minimumDifference == 0) {
					return 0;
				}
			}
		}

		return minimumDifference;
	}

	public static void main(String[] args) {

		int[] arr = { 82, 226, 64, 34, 73, 84, 92 };
		// getAbsoluteDiff(arr);

		// System.out.println(minimumAbsoluteDifference(arr));
		// minSum(arr);
		// maxSum(arr);
		System.out.println("Minimum Difference : " + getMinAbsDifference(arr));
	}

}
