package com.huawei.utility;

/*If multiples of 3 print Hello
If multiples of 5 print World
*/
public class Result_Test {
	public static void helloWorld(int n) {

		int a = 3, b = 5, c = 7;
		for (int i = 1; i <= n; i++) {
			String s = "";
			if (i == a) {
				a = a + 3;
				s = s + "Hello";
			}
			if (i == b) {
				b = b + 5;
				s = s + "World";
			}
			if (i == c) {
				c = c + 7;
				s = s + "From Praveen";
			}
			if (s == "") {
				System.out.println(i);
			} else {
				System.out.println(s);
			}
		}

	}

	public static void main(String[] args) {
		helloWorld(20);
	}
}