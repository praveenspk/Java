package com.huawei.utility;

public class LongOperations {
	public static void main(String[] args) {
		long longWithL = 1000 * 60 * 60 * 24 * 365L;
		long longWithOutL = 1000 * 60 * 60 * 24 * 365;
		System.out.println("LongWithL : " + longWithL + " LongWithOutL : " + longWithOutL);

	}

}
