package com.huawei.practice;

public class ImmutableTest {
	public static void main(String[] args) {

		ImmutableClass test = new ImmutableClass("ImmutableClass", "com.huawei.practice");
		System.out.println("Class Name : " + test.getClassName() + "\nPackage Name :  " + test.getPackageName());

		// test.setClassName("ImmutableTest"); //Compile Time Exception
		// test.setPackageName("com.huawei.practice"); //Compile Time Exception

	}

}
