package com.huawei.practice;

import edu.emory.mathcs.backport.java.util.Arrays;

public class CopyOneArrayToAnthorArray {

	static int[] copyOneArrayToAnthorArray(int arr[]) {

		int[] newArr = new int[arr.length];

		// Method 1:
		System.arraycopy(arr, 0, newArr, 0, arr.length);
		for (int i = 0; i < newArr.length; i++) {
			// System.out.println("Using System Class Method : " + newArr[i]);
			Arrays.sort(newArr);
			System.out.println(newArr[i]);
		}

		// Method 2 :
		for (int i = 0; i < arr.length; i++) {
			newArr[i] = arr[i];
			// System.out.println(newArr[i]);
		}

		return newArr;
	}

	static void largestElement(int[] arr) {
		Arrays.sort(arr);
		int len = arr.length;
		System.out.println("Maximum Number in an Array : " + arr[len - 1]);
		System.out.println("Minimum Number in an Array : " + arr[0]);

	}

	public static void main(String[] args) {

		int[] array = copyOneArrayToAnthorArray(new int[] { 12, 324, 656, 7685, 3543, 567, 23, 2 });
		for (int i = 0; i < array.length; i++) {
			System.out.println(array[i]);
		}
		largestElement(new int[] { 12, 324, 656, 7685, 3543, 567, 23, 2 });
		// System.out.println(copyOneArrayToAnthorArray(new int[] { 12, 324, 656, 7685,
		// 3543, 567, 23, 2 }));

	}
}
