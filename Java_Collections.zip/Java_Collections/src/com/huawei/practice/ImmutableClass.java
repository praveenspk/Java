package com.huawei.practice;

public final class ImmutableClass {

	private String className;
	private String packageName;

	private ImmutableClass() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ImmutableClass(String className, String packageName) {
		super();
		this.className = className;
		this.packageName = packageName;
	}

	public String getClassName() {
		return className;
	}

	public String getPackageName() {
		return packageName;
	}

	@Override
	public String toString() {
		return "ImmutableClass [className=" + className + ", packageName=" + packageName + "]";
	}

}
