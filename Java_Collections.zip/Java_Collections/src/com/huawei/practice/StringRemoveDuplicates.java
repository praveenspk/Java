package com.huawei.practice;

public class StringRemoveDuplicates {

	// Using String methods
	static void removeDuplicates(String input) {
		String str = new String();
		for (int i = 0; i < input.length(); i++) {
			char c = input.charAt(i);

			if (str.indexOf(c) < 0) {
				str += c;
			}
		}
		System.out.println(str);

	}

	// Without using predefined methods
	static void removeDuplicate(String str) {
		String result = "";
		for (int i = 0; i < str.length(); i++) {
			for (int j = i + 1; j < str.length(); j++) {
				if (str.charAt(i) == str.charAt(j)) {
					System.out.println();
					result = result + str.charAt(i);

				}
			}
		}
		System.out.println("Removed Duplicates are  : " + result);

	}

	static void getDistinctString() {
		String s = "Praveenkumar";
		String s2 = "";
		for (int i = 0; i < s.length(); i++) {
			Boolean found = false;
			for (int j = 0; j < s2.length(); j++) {
				if (s.charAt(i) == s2.charAt(j)) {
					found = true;
					break; // don't need to iterate further
				}
			}
			if (found == false) {
				s2 = s2.concat(String.valueOf(s.charAt(i)));
			}
		}
		System.out.println(s2);
	}

	public static void main(String[] args) {
		// removeDuplicates("Praveenn");
		removeDuplicate("praveenkumar");
		getDistinctString();
	}

}
