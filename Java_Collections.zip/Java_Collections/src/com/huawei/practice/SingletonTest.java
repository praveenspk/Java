package com.huawei.practice;

public class SingletonTest {

	private SingletonTest singleton;

	private SingletonTest() {
	}

	public static SingletonTest getInstance() {

		return new SingletonTest();
	}

	public static void main(String[] args) {
		SingletonTest test = SingletonTest.getInstance();

	}

}
