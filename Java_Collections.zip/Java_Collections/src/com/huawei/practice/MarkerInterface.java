package com.huawei.practice;

public interface MarkerInterface {

}
