package com.huawei.random;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Random;
import java.util.SplittableRandom;
import java.util.concurrent.ThreadLocalRandom;

//import org.apache.commons.rng.UniformRandomProvider;
//import org.apache.commons.rng.simple.RandomSource;

/*Random number can be generated using the below built-in ways provided by Java.

1. Using Math.random() method
2. Using Random Class
3. Using ThreadLocalRandom
4. Using SecureRandom
5. Using SplittableRandom
6. Apache Commons – RandomSource*/

public class RandomGeneration {

	// Method 1 : Using Math.random()
	static void getMathRandom() {
		System.out.println("========From==>  Math.random()");
		System.out.println(Math.random() * 10);
	}

	// Method 2 : Using Random Class

	static void getRandom() {
		Random rand = new Random();
		System.out.println("========From==>" + rand.getClass());
		System.out.println(rand.nextInt());
		System.out.println(rand.nextDouble());
		System.out.println(rand.nextFloat());
		System.out.println(rand.nextGaussian());
		System.out.println(rand.nextBoolean());
		System.out.println(rand.nextInt(1000));

	}

	// Method 3 : Using ThreadLocalRandom
	static void getThreadLocalRandom() {

		ThreadLocalRandom random = ThreadLocalRandom.current();
		System.out.println("========From==>" + random.getClass());
		System.out.println(random.nextInt());
		System.out.println(random.nextDouble());
		System.out.println(random.nextFloat());
		System.out.println(random.nextInt(1000));
		System.out.println(random.nextGaussian());
	}

	// Method 4 : Using SecureRandom
	static void secureRandom() {

		try {
			SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
			System.out.println("====From=>" + random.getClass());
			System.out.println(random.nextInt());
			System.out.println(random.nextFloat());
			System.out.println(random.nextDouble());
			System.out.println(random.nextGaussian());
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// Method 5 : Using SplittableRandom
	static void splittableRandom() {
		SplittableRandom random = new SplittableRandom();
		System.out.println("========From==>" + random.getClass());
		System.out.println(random.nextInt());
		System.out.println(random.nextDouble());
		System.out.println(random.nextBoolean());

	}

	// Method 6 : Apache Commons �C RandomSource
	/*
	 * static void randomSource() { UniformRandomProvider randomProvider =
	 * RandomSource.create(RandomSource.JDK); System.out.println("========From==>" +
	 * randomProvider.getClass()); System.out.println(randomProvider.nextBoolean());
	 * System.out.println(randomProvider.nextDouble());
	 * System.out.println(randomProvider.nextInt());
	 * System.out.println(randomProvider.nextInt(678)); }
	 */

	public static void main(String[] args) {
		getMathRandom();
		getRandom();
		getThreadLocalRandom();
		secureRandom();
		splittableRandom();

	}

}
