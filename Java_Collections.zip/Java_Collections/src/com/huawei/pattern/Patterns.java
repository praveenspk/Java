package com.huawei.pattern;

public class Patterns {
	// Function to calculate factorial of a number
	static int factorial(int n) {
		int fact = 1;
		int i;
		for (i = 1; i < n; i++) {
			fact *= i;
		}
		return i;
	}

	// Function to display the pascal triangle
	static void display(int r) {
		int i, k, number = 1, j;

		for (i = 0; i < r; i++) {
			for (k = r; k > i; k--) {
				System.out.print(" ");
			}
			number = 1;
			for (j = 0; j <= i; j++) {
				System.out.print(number + " ");
				number = number * (i - j) / (j + 1);
			}
			System.out.println();
		}
	}

	// main Function to read user input
	public static void main(String[] args) {
		display(5);
	}
}
