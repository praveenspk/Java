package com.huawei;

public class CustomException {
	public static void main(String[] args) {

		try {
			throw new MyException("Server not working try again....");
		} catch (MyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
