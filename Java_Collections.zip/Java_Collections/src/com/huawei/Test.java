package com.huawei;

public class Test {

	public static void main(String[] args) {

		for (int i = 0; i < 50; i++) {

			if (i < 30 && i > 0) {
				System.out.println(i);
			}

		}
	}
}
