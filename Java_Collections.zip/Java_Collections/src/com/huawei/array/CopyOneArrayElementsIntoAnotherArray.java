package com.huawei.array;

import java.util.Arrays;

public class CopyOneArrayElementsIntoAnotherArray {

	private static void copyArrayElementsIntoAnotherArray(int[] oldArray) {

		int[] newArray = null;
		/**
		 * new Array declaration
		 */
		newArray = new int[oldArray.length];

		/**
		 * copy operation from old array to new array
		 */

		// System.arraycopy(src, srcPos, dest, destPos, length); is used to copy one
		// Array elements into another Array

		System.arraycopy(oldArray, 0, newArray, 0, oldArray.length);

		System.out.println("Array Elements After Copy are::");
		System.out.println(Arrays.toString(newArray));

	}

	private static int[] copyOnearrayToAnotherArray(int[] oldArray) {

		int[] newArray = null;
		/**
		 * new Array declaration
		 */
		newArray = new int[oldArray.length];

		/**
		 * copy operation from old array to new Array index by index
		 */

		System.out.println("Old Array : ");
		for (int i = 0; i < oldArray.length; i++) {
			System.out.println(oldArray[i]);
			newArray[i] = oldArray[i];
		}

		return newArray;

	}

	@SuppressWarnings("unused")
	private static int[] deleteElementAtSpecifiedIndex(int[] arr, int index) {

		int[] newArray = null;

		/**
		 * Array Initialization
		 */

		newArray = new int[arr.length - 1];
		/**
		 * copy old array elements into new Array before index
		 */

		for (int i = 0; i < index; i++) {
			newArray[i] = arr[i];
		}

		for (int i = index + 1; i < arr.length; i++) { // 3,4
			newArray[i - 1] = arr[i];
		}

		return newArray;

	}

	public static void main(String[] args) {
		System.out.println("New Array Elements : " + Arrays.toString(
				copyOnearrayToAnotherArray(new int[] { 54, 34, 55, 54, 3, 4, 12, 67, 32, 34, 55, 53, 54, 67 })));

		copyArrayElementsIntoAnotherArray(new int[] { 54, 34, 55, 54, 3, 4, 12, 67, 32, 34, 55, 53, 54, 67 });
	}

}
