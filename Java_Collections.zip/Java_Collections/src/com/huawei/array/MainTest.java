package com.huawei.array;

import java.util.Arrays;

import  org.apache.commons.lang3.SerializationUtils;
public class MainTest {
	public static void main(String args[]) {
		// TODO Auto-generated constructor stub
		Employee[] emp = new Employee[2];
		emp[0] = new Employee(84119411, "Praveen", "Kumar", new Department(1, "GSC"));
		emp[1] = new Employee(84119423, "Suresh", "Thimothy", new Department(2, "GNOC"));
		System.out.println(emp[0].getDepartment() + "\n" + emp[1]);
		 Employee[] copiedArray =  SerializationUtils.clone(emp);  
		emp[0].setFirstName("Huawei");
	        emp[0].getDepartment().setName("Huawei");
	         
	        //Verify the change in original array - CHANGED
	        System.out.println(emp[0].getFirstName());                   
	        System.out.println(emp[0].getDepartment().getName());        
	 
	        System.out.println();
	        //Verify the change in deep copied array - UNCHANGED
	        System.out.println(copiedArray[0].getFirstName());              
	        System.out.println(copiedArray[0].getDepartment().getName());   
	}

}
