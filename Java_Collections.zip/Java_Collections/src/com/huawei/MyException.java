package com.huawei;

public class MyException extends Exception {

	private String str;

	public MyException(String str) {
		super();
		this.str = str;
	}

	@Override
	public String toString() {
		return "MyException [str=" + str + "]";
	}

}
