package com.huawei.enumeration;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class FailSafeIterator {

	static void getIterate() {
		List al = new ArrayList();
		al.add("1");
		al.add("2");
		al.add("3");
		al.add("4");
		al.add("5");

		System.out.println("List before Iteration " + al);
		int indexFlag = 0;
		Iterator it = al.iterator();
		while (it.hasNext()) {

			it.next();
			indexFlag++;

			if (indexFlag == 3) {

				it.remove();
			}

		}
		System.out.println("List after Iteration" + al);
	}

	static void failSafe() {
		CopyOnWriteArrayList list = new CopyOnWriteArrayList();
		list.add("Praveen");
		list.add("Huawei");
		list.add("Java");
		list.add("s84119411");
		list.add("Bangalore");
		list.add("India");
		list.add("2");
		int indexFlag = 0;
		Iterator it = list.iterator();
		while (it.hasNext()) {
			list.add("516390");
			System.out.println(it.next());

		}

	}

	public static void main(String[] args) {

		getIterate();
		failSafe();

		
	}

}
