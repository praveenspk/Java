package com.huawei.enumeration;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Vector;

/*
Enumeration can traverse limited collection such as Vectors and HashTable. 
Whereas Iterator can be used to almost all the Collection*/

public class DiffBetweenEnumerationAndIteration {
	static void getEnumeration() {
		Vector v = new Vector();
		v.add("Praveen");
		v.add("Java");
		v.add("Huawei");
		v.add("GSC");
		v.add("Bangalore");
		v.add("India");
		System.out.println("=======Traversing through Enumeration======");
		Enumeration enumeration = v.elements();

		while (enumeration.hasMoreElements()) {
			System.out.println(enumeration.nextElement());
			// v.add("516390");
		}
	}

	static void getIterator() {
		int flag = 0;
		List list = new ArrayList();
		list.add("Praveen");
		list.add("s84119411");
		list.add("spraveen@spk.com");
		list.add(9490137902L);
		list.add("Bangalore");
		list.add("India");
		// Using Iterator
		Iterator iterate = list.iterator();
		System.out.println("======Traversing through Iterator=====");
		while (iterate.hasNext()) {
			System.out.println(iterate.next());
			// list.add("Huawei "); //java.util.ConcurrentModificationException

		}
		System.out.println("After Removal : " + list);

		// Using ListIterator
		ListIterator itr = list.listIterator();
		System.out.println("======Traversing through ListIterator=====");
		while (itr.hasNext()) {
			System.out.println(itr.next());
			itr.add("516390");

			if (flag == 2) {
				itr.remove();
			}
		}
		System.out.println("After Adding element : " + list);

	}

	static void iteratorTest() {
		List al = new ArrayList();
		al.add("1");
		al.add("2");
		al.add("3");
		al.add("4");
		al.add("5");

		System.out.println("List before Iteration " + al);
		int indexFlag = 0;
		Iterator it = al.iterator();
		while (it.hasNext()) {

			it.next();
			indexFlag++;

			if (indexFlag == 2) {

				it.remove();
			}

		}
		System.out.println("List after Iteration" + al);
	}

	public static void main(String[] args) {
		getEnumeration();
		getIterator();
		iteratorTest();

	}

}
