package com.huawei.utility;

public abstract class InterfaceDemoAbstract implements InterfaceDemo {

	public abstract void display();

	public void getMessage() {

		System.out.println("From getMessage()");
	}

}
