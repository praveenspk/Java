package com.huawei.utility;

public interface InterfaceDemo {
	
	public  void showA();

	public void showB();

}
