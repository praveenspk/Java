package com.huawei.strings;

public class StringToInteger {
	public static void main(String[] args) {
		String str = "9835635";
		Integer convert = Integer.valueOf(str);
		System.out.println("Value is  : " + convert);

	}

}
