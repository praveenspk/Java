package com.huawei.exception;

public class TestException {
	public static void main(String[] args) {
		int x=1;
		System.out.println(~x);
	}

}
