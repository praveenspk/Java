package com.huawei.javaMaster;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[][][] arr = { { { 1, 2,3 }, { 3, 4,3 } } };

		for (int i = 0; i < 3; i++) {

			for (int j = 0; j < 3; j++) {

				for (int k = 0; k < 3; k++) {

					//System.out.print(arr[i][j][k] + " ");
				}

				//System.out.println();
			}
			//System.out.println();
			System.out.println(System.getenv());
		}

	}

}
